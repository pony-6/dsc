<?php

return [
    'auth_key' 						=> env('CASHIER_AUTH_KEY', null),
    'cipher'                        => 'AES-256-CBC',
];
