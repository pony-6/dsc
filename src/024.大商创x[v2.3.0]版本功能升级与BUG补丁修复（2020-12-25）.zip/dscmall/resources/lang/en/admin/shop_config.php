<?php

return [
    'pc_shop_config' => 'basic configuration',
    'pc_shop_config_tips' => [
        'PC side display Settings, only control PC side related configuration items, please fill in the information carefully'
    ],
];
