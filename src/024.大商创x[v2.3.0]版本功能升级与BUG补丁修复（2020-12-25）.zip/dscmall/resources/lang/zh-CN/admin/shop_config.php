<?php

return [
    'pc_shop_config' => '基本配置',
    'pc_shop_config_tips' => [
        'PC端显示设置，仅控制PC端相关配置项，请谨慎填写信息；'
    ],
];
