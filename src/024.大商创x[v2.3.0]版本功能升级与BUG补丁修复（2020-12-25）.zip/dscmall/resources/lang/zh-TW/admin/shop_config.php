<?php

return [
    'pc_shop_config' => '基本配置',
    'pc_shop_config_tips' => [
        'PC端顯示設置，僅控制PC端相關配置項，請謹慎填寫信息；'
    ],
];
